<?php

$to="hrt143@yandex.com";

$botToken="5178401182:AAFdsj9L5FYzuV68QaiEe2A_iMRSD3eCGpA";
$chatId= '-707503818';  //** ===>>>NOTE: this chatId MUST be the chat_id of a person, NOT another bot chatId !!!**


?>